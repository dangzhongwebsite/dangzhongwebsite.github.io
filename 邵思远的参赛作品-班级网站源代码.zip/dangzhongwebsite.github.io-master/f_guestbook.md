---
layout: page
title: Guestbook
comments: yes
permalink: /guestbook/
---
## Hi, welcome to leave a message here.:)

> To follow the path, look to the master, follow the master, walk with the master, see through the master, become the master.

